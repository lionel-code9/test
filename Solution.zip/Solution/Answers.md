

1. 5 hours.

2. I have choosen this code structure because I know that is the simpliest one HTML and Javascript. Php i also a good one but would need to install a server to run it.

3. I would find out how to split() the variable str.

4. A preddy good one cause it has tested me on all of the basics about software development.

